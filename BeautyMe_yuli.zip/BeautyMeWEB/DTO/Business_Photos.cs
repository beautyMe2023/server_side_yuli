﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class Business_PhotosDTO
    {
      public  string url_photo;
       public string Business_number;
    }
}