﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class AppointmentDTO
    {
        public int Number_appointment;
        public System.DateTime Date;
        public string Is_client_house;
        public int Business_Number;
        public string Appointment_status;
        public string ID_Client;
        public double End_Hour;
        public double Start_Hour;
        public int Type_Treatment_Number;

    }
}


