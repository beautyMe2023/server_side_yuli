﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class SearchPeopleDTO
    {
        public string id_number;
        public string password;
    }
}