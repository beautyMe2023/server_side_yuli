﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class BusinessDiaryDTO
    {
        public int Business_id;
        public DateTime Date;
        public double Start_time;
        public double End_time;
    }
}