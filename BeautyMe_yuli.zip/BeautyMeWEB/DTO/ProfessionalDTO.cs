﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class ProfessionalDTO
    {
        public string ID_number;
        public string First_name;
        public string Last_name;
        public System.DateTime birth_date;
        public string gender;
        public string phone;
        public string Email;
        public string AddressStreet;
        public string AddressHouseNumber;
        public string AddressCity;
        public string password;
        public int Business_Number;
        public string userType;
        public string token;
        public string ProfilPic;

    }
}