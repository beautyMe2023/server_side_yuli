﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BeautyMe;

namespace BeautyMeWEB.DTO
{
    public class BusinessReviewDTO
    {
        public int Review_Number;
        public int Number_appointment;
        public string Cleanliness;
        public string Professionalism;
        public string On_time;
        public string Overall_rating;
        public string Client_ID_number;
        public int Business_Number;
        public string Comment;
    }
}