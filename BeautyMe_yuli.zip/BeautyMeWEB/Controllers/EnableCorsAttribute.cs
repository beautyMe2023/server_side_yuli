﻿using System;

namespace BeautyMeWEB.Controllers
{
    internal class EnableCorsAttribute : Attribute
    {
    }
}