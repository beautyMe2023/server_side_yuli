﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class Appointment_can_give_treatmentDTO
    {
        public int number;
        public int Type_treatment_Number;
        public int Number_appointment;
    }
}