﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BeautyMeWEB.DTO
{
    public class CategoryDTO
    {
        public int Category_Number;
        public string Name;
    }
}